function calculate(){
   var a= parseInt (document.getElementById('lanOne'));
   var b= parseInt (document.getElementById('lanTwo'));
   var c= parseInt (document.getElementById('lanTree'));
   var d= parseInt (document.getElementById('lanFour'));
}


if(a<100 || b>100 || c>100 || d>100){

    alert("Please enter the corrcet value")

}
else{
    var obtain=a+b+c+d;
    document.getElementById('Obtain').innerHTML=obtain;
    var per=obtain/400*100;
    document.getElementById('per').innerHTML=per;

    if((a>40 && b>40 && c>40 && d>40 )){
        document.getElementById('remark').innerHTML="Pass";
        

    }
else{
    document.getElementById('remark').innerHTML="Fail";


}
     
    
}
return false;